from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship

# 连接数据库
engine = create_engine(
    "mysql+pymysql://root:123456@127.0.0.1:3306/day132?charset=utf8",
    max_overflow=0,  # 超过连接池大小外最多创建的连接数
    pool_size=5,  # 连接池大小
    # pool_timeout=30,  # 连接池中没有线程最多等待时间，否则报错
    # pool_recycle=-1,  # 多久之后对连接池中的连接进行回收（重置）-1不回收
)

# 怎么去执行原生SQL
# def test():
#     cursor = engine.execute()
#     cursor.close()
Base = declarative_base()

class Book(Base):
    __tablename__ = "book"
    id = Column(Integer, primary_key=True)
    title = Column(String(32), index=True)
    create_time = Column(DateTime)
    # 创建外键
    publish_id = Column(Integer, ForeignKey("publish.id"))
    # 不生成字段 只是为了查询
    publish = relationship("Publish", backref="user")

    tags = relationship("Tag", secondary="book2tag", backref="tags")



class Publish(Base):
    __tablename__ = "publish"

    id = Column(Integer, primary_key=True)
    title = Column(String(32), index=True)


class Tag(Base):
    __tablename__ = "tag"

    id = Column(Integer, primary_key=True)
    title = Column(String(32), index=True)


class Book2Tag(Base):
    __tablename__ = "book2tag"

    id = Column(Integer, primary_key=True)
    book_id = Column(Integer, ForeignKey("book.id"))
    tag_id = Column(Integer, ForeignKey("tag.id"))

# 单表的增删改查
from sqlalchemy.orm import sessionmaker, scoped_session
Session = sessionmaker(bind=engine)
# session = Session()
session = scoped_session(Session)#type:session
# 增加
# tag_obj = Tag(title="Python")
# session.add(tag_obj)
# session.commit()
# session.close()
# 查询
# tag_obj = session.query(Tag).filter_by(id=1).first()
# print(tag_obj.title)
# 删除
# session.query(Tag).filter(Tag.title == "Python").delete()
# session.commit()
# 修改
# session.query(Tag).filter_by(id=1).update({Tag.title: "王者毒药"})
#
# session.commit()
# 条件查询
# tag_objs = session.query(Tag).filter(Tag.id > 2).all()
# tag_objs = session.query(Tag).filter(~(Tag.id > 2)).all()
# tag_objs = session.query(Tag).filter(Tag.id.between(2,4)).all()
# tag_objs = session.query(Tag).filter(Tag.id > 2).all()
#
# print(tag_objs)
# for obj in tag_objs:
#     print(obj.title)

from sqlalchemy import and_, or_
# tag_objs = session.query(Tag).filter(and_(Tag.id>2, Tag.id<4)).all()
# tag_objs = session.query(Tag).filter(or_(Tag.id>2, Tag.id<4)).all()
# tag_objs = session.query(Tag).filter(or_(
#     Tag.id<1,
#     and_(Tag.id>3, Tag.title=="Linux")
# )).all()
#
#
# for obj in tag_objs:
#     print(obj.title)
# 模糊查询
# tag_objs = session.query(Tag).filter(Tag.title.like("L%")).all()
# 切片
# tag_objs = session.query(Tag).filter(Tag.title.like("L%")).all()[0:3]
# 排序
# tag_objs = session.query(Tag).order_by(Tag.id.desc()).all()
# tag_objs = session.query(Tag).order_by(Tag.id.asc()).all()
# 分组
# ret = session.query(Tag).group_by(Tag.title).all()
# 聚合函数
from sqlalchemy.sql import func

# ret = session.query(
#     Tag.title,
#     func.max(Tag.id),
#     func.min(Tag.id)
# ).group_by(Tag.title).having(func.max(Tag.id > 2)).all()
# print(ret)
# for obj in ret:
#    print(obj.title)
# 连表
# ret = session.query(Book, Publish).filter(Book.publish_id == Publish.id).all()
# 结果列表 套元组 元组里面两个对象 对应query里面的两个表
# ret = session.query(Book).join(Publish).all()
# 结果是列表 里面是query里面的表的对象 inner join
# ret = session.query(Book).join(Publish, isouter=True).all()
# # left join
# print(ret)
# for obj in ret:
#     print(obj.title)


# 基于relationship 添加
# book_obj = Book(title="睡觉", publish=Publish(title="睡神出版社"))
# session.add(book_obj)
# session.commit()
# 基于relationship 查找
# book_obj = session.query(Book).filter(Book.id== 1).first()
# print(book_obj.publish.title)
# publish_obj = session.query(Publish).filter(Publish.id== 1).first()
# print(publish_obj.user)


# M2M 创建
# book_obj = Book(title="SQLAlchemy")
# tag_obj = Tag(title="Flask")
#
# book2tag_obj = Book2Tag(book_id=book_obj.id, tag_id=tag_obj.id)
# session.add_all([
#     book_obj,
#     tag_obj,
#     book2tag_obj,
# ])
# session.commit()
# book = Book(title="测试")
# book.tags = [Tag(title="测试标签1"), Tag(title="测试标签2")]
# session.add(book)
# session.commit()
# session.close()

tag = Tag(title="LOL")
tag.tags = [Book(title="大龙刷新时间"), Book(title="小龙刷新时间")]
session.add(tag)
session.commit()

session.close()






# if __name__ == '__main__':
#    # test()
#     Base.metadata.create_all(engine)
   #  Base.metadata.drop_all(engine)